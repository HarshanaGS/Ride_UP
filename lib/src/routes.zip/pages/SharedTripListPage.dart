// 📄 File: shared_trip_list_page.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/user.dart';
import '../utils/firebase_user.dart';
import '../utils/status_request.dart';

class SharedTripListPage extends StatelessWidget {
  const SharedTripListPage({super.key});

  Future<void> _requestToJoinTrip(String requestId, BuildContext context) async {
    Usuario? user = await FirebaseUser.getLoggedUserData();
    if (user == null) return;

    await FirebaseFirestore.instance.collection('join_requests').add({
      'request_id': requestId,
      'passenger_id': user.id,
      'passenger_name': user.name,
      'status': 'pending',
      'timestamp': DateTime.now().toIso8601String(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Join request sent to driver.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Available Shared Trips")),
      body: FutureBuilder<Usuario?>(
        future: FirebaseUser.getLoggedUserData(),
        builder: (context, userSnapshot) {
          if (!userSnapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          String? userId = userSnapshot.data?.id;

          return FutureBuilder<QuerySnapshot>(
            future: FirebaseFirestore.instance
                .collection('requests')
                .where('status', whereIn: [StatusRequisicao.THE_WAY, StatusRequisicao.trip])
                .where('allow_shared', isEqualTo: true)
                .get(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.data!.docs.isEmpty) {
                return const Center(child: Text("No shared trips available."));
              }

              var docs = snapshot.data!.docs;

              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (context, index) {
                  var trip = docs[index].data() as Map<String, dynamic>;
                  final requestId = docs[index].id;
                  final origin = trip['origin'] ?? {};
                  final destination = trip['destination'] ?? {};
                  final driver = trip['driver'] ?? {};
                  final passengers = trip['passengers'] ?? [];

                  String formattedDate = 'Unknown';
                  if (trip['start_date'] != null) {
                    try {
                      final date = DateTime.parse(trip['start_date']);
                      formattedDate = DateFormat('yyyy-MM-dd – HH:mm').format(date);
                    } catch (_) {}
                  }

                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(color: Colors.grey.shade300),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      title: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('From: ${origin['road'] ?? 'N/A'}'),
                          Text('To: ${destination['road'] ?? 'N/A'}'),
                          Text('Started at: $formattedDate',
                              style: const TextStyle(fontSize: 12, color: Colors.grey)),
                          Text('Driver: ${driver['name'] ?? 'N/A'}',
                              style: const TextStyle(fontSize: 13)),
                        ],
                      ),
                      trailing: ElevatedButton(
                        onPressed: () => _requestToJoinTrip(requestId, context),
                        child: const Text("Request to Join"),
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}